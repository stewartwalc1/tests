public class A {
    public void print_A(){
        System.out.println("Class A");
    }
}
