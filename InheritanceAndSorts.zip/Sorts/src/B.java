public class B extends A{
    public void print_B(){
        System.out.println("Class B");
    }
}
