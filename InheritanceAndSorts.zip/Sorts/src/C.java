public class C extends A{
    public void print_C(){
        System.out.println("Class C");
    }
}

