public class D extends A{
    public void print_D(){
        System.out.println("Class D");
    }
}
