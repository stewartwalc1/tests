public class Multithree extends Singletwo{
    public void print_forlife(){
        System.out.println("for life");
    }
}
