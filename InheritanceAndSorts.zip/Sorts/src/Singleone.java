public class Singleone {
    public void print_red(){
        System.out.println("Red");
    }
}
