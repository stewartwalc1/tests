public class Singletwo extends Singleone {
        public void print_hawks(){
            System.out.println("Hawks");
        }

}
