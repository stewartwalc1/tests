public class child implements three{
    public void print_red(){
        System.out.println("Red");
    }
    public void show(){
        three.super.show();
    }

    public void print_hawks(){
        System.out.println("Hawks");
    }
}
