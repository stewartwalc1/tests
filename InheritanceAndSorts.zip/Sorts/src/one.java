public interface one {
    public void print_red();


}
