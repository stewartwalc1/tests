public interface two {
    public void print_red();
}
